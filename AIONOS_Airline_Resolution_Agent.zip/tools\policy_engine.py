import json


def load_policies():
    with open("data/policies.json", "r", encoding="utf-8") as file:
        return json.load(file)


def check_cancellation_policy():
    policies = load_policies()

    return {
        "refund_allowed": policies["cancellation"]["refund_allowed"],
        "refund_method": policies["cancellation"]["refund_method"],
        "refund_processing_time": policies["cancellation"]["refund_processing_time"],
        "free_rebooking_within_hours": policies["cancellation"]["free_rebooking_within_hours"]
    }


def check_delay_policy(delay_hours):
    policies = load_policies()

    if delay_hours > 5:
        return {
            "meal_voucher": True,
            "lounge_access": True,
            "hotel_accommodation": True,
            "hotel_duration": "delayed hours only"
        }

    elif delay_hours > 3:
        return {
            "meal_voucher": True,
            "lounge_access": True,
            "hotel_accommodation": False
        }

    elif delay_hours > 0:
        return {
            "meal_voucher": "₹500",
            "lounge_access": False,
            "hotel_accommodation": False
        }

    return {
        "meal_voucher": False,
        "lounge_access": False,
        "hotel_accommodation": False
    }


def check_fare_difference(fare_difference):
    policies = load_policies()

    maximum_waiver = policies["fare_difference"]["maximum_waiver_without_supervisor"]

    if fare_difference <= maximum_waiver:
        return {
            "supervisor_required": False,
            "customer_pays": False
        }

    return {
        "supervisor_required": True,
        "customer_pays": True,
        "reason": "Fare difference exceeds agent authority"
    }