import json


def load_bookings():
    with open("data/bookings.json", "r", encoding="utf-8") as file:
        return json.load(file)


def get_bookings_by_pnr(pnr):
    bookings = load_bookings()

    customer_bookings = []

    for booking in bookings:
        if booking["pnr"].lower() == pnr.lower():
            customer_bookings.append(booking)

    return customer_bookings