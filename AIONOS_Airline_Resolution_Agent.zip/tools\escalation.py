def escalate_to_supervisor(customer_name, pnr, reason):
    return {
        "action": "Supervisor Escalation",
        "customer": customer_name,
        "pnr": pnr,
        "status": "Escalated",
        "reason": reason,
        "message": "This case has been escalated to a supervisor for approval."
    }