import json
from datetime import datetime

from agent.llm import ask_gemini

from tools.customer_lookup import get_customer_by_pnr
from tools.booking_lookup import get_bookings_by_pnr

from tools.policy_engine import (
    check_cancellation_policy,
    check_delay_policy,
    check_fare_difference
)

from tools.actions import (
    process_refund,
    rebook_flight,
    issue_meal_voucher,
    provide_lounge_access,
    arrange_hotel
)

from tools.escalation import escalate_to_supervisor


def save_log(log_data):
    try:
        with open(
            "logs/conversation_log.json",
            "r",
            encoding="utf-8"
        ) as file:
            data = json.load(file)

    except (FileNotFoundError, json.JSONDecodeError):
        data = {"conversations": []}

    data["conversations"].append(log_data)

    with open(
        "logs/conversation_log.json",
        "w",
        encoding="utf-8"
    ) as file:
        json.dump(
            data,
            file,
            indent=2,
            ensure_ascii=False
        )


def generate_customer_response(
    customer,
    bookings,
    actions,
    escalation,
    customer_message
):
    """
    Gemini converts the structured agent decision
    into a natural-language customer response.
    """

    prompt = f"""
You are an airline customer service assistant.

Respond politely and clearly to the customer.

IMPORTANT RULES:
- Use ONLY the information provided below.
- Do not invent airline policies.
- Do not invent compensation.
- Do not promise anything that was not approved.
- If supervisor escalation is required, clearly explain that approval is needed.
- Keep the response concise and customer-friendly.
- If the customer is angry or frustrated, acknowledge their concern politely.

CUSTOMER:
{json.dumps(customer, indent=2, ensure_ascii=False)}

BOOKINGS:
{json.dumps(bookings, indent=2, ensure_ascii=False)}

CUSTOMER MESSAGE:
{customer_message}

ACTIONS ALREADY APPROVED BY THE POLICY ENGINE:
{json.dumps(actions, indent=2, ensure_ascii=False)}

SUPERVISOR ESCALATION:
{json.dumps(escalation, indent=2, ensure_ascii=False)}

Write the final response to the customer.
"""

    try:
        return ask_gemini(prompt)

    except Exception:
        return "Your request has been processed according to the applicable airline policy."


def resolve_customer_issue(
    pnr,
    issue_type,
    customer_message="",
    fare_difference=0
):
    """
    Main customer resolution function.

    The Python policy engine makes the business decision.
    Gemini is used to generate the final natural-language response.
    """

    # --------------------------------------------------
    # 1. CUSTOMER LOOKUP
    # --------------------------------------------------

    customer = get_customer_by_pnr(pnr)

    if not customer:
        return {
            "status": "Error",
            "message": "Customer not found."
        }

    # --------------------------------------------------
    # 2. BOOKING LOOKUP
    # --------------------------------------------------

    bookings = get_bookings_by_pnr(pnr)

    if not bookings:
        return {
            "status": "Error",
            "message": "No booking found for this customer."
        }

    # --------------------------------------------------
    # 3. INITIAL RESULT
    # --------------------------------------------------

    result = {
        "customer": customer,
        "actions": [],
        "escalation": None
    }

    # --------------------------------------------------
    # 4. CANCELLATION HANDLING
    # --------------------------------------------------

    if issue_type == "cancellation":

        policy = check_cancellation_policy()

        if policy["refund_allowed"]:

            action = process_refund(
                customer["name"],
                pnr
            )

            result["actions"].append(action)

    # --------------------------------------------------
    # 5. DELAY HANDLING
    # --------------------------------------------------

    elif issue_type == "delay":

        delayed_booking = None

        for booking in bookings:

            if booking.get("status") == "Delayed":

                delayed_booking = booking
                break

        if delayed_booking:

            delay_hours = delayed_booking["delay_hours"]

            policy = check_delay_policy(
                delay_hours
            )

            # Meal voucher
            if policy["meal_voucher"]:

                amount = "₹500"

                if isinstance(
                    policy["meal_voucher"],
                    str
                ):
                    amount = policy["meal_voucher"]

                result["actions"].append(
                    issue_meal_voucher(
                        customer["name"],
                        amount
                    )
                )

            # Lounge access
            if policy["lounge_access"]:

                result["actions"].append(
                    provide_lounge_access(
                        customer["name"]
                    )
                )

            # Hotel
            if policy["hotel_accommodation"]:

                result["actions"].append(
                    arrange_hotel(
                        customer["name"],
                        policy["hotel_duration"]
                    )
                )

    # --------------------------------------------------
    # 6. FARE DIFFERENCE HANDLING
    # --------------------------------------------------

    if fare_difference > 0:

        fare_policy = check_fare_difference(
            fare_difference
        )

        if fare_policy["supervisor_required"]:

            result["escalation"] = (
                escalate_to_supervisor(
                    customer["name"],
                    pnr,
                    fare_policy["reason"]
                )
            )

    # --------------------------------------------------
    # 7. GEMINI RESPONSE GENERATION
    # --------------------------------------------------

    if customer_message:

        result["customer_response"] = (
            generate_customer_response(
                customer,
                bookings,
                result["actions"],
                result["escalation"],
                customer_message
            )
        )

    else:

        result["customer_response"] = (
            "Your request has been processed according to the applicable airline policy."
        )

    # --------------------------------------------------
    # 8. CONVERSATION LOG
    # --------------------------------------------------

    log_data = {
        "timestamp": datetime.now().isoformat(),
        "pnr": pnr,
        "issue_type": issue_type,
        "customer_message": customer_message,
        "fare_difference": fare_difference,
        "result": result
    }

    save_log(log_data)

    return result