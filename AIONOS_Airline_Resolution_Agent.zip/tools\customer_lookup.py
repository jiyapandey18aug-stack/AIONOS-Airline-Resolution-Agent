import json


def load_customers():
    with open("data/customers.json", "r", encoding="utf-8") as file:
        return json.load(file)


def get_customer_by_pnr(pnr):
    customers = load_customers()

    for customer in customers:
        if customer["pnr"].lower() == pnr.lower():
            return customer

    return None