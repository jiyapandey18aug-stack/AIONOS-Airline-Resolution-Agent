import streamlit as st

from agent.agent import resolve_customer_issue
from tools.customer_lookup import get_customer_by_pnr


st.set_page_config(
    page_title="AIONOS Airline Resolution Agent",
    page_icon="✈️",
    layout="centered"
)


st.title("✈️ AIONOS Airline Resolution Agent")

st.caption(
    "AI-powered customer support for airline disruptions"
)

st.divider()


pnr = st.text_input(
    "🔑 PNR",
    placeholder="Example: SK4821X"
)


customer_message = st.text_area(
    "💬 Customer Issue",
    placeholder=(
        "Example: My flight is delayed by 6 hours. "
        "I need a hotel."
    ),
    height=120
)


if st.button(
    "Resolve Customer Issue",
    type="primary"
):

    if not pnr:

        st.warning("Please enter your PNR.")

    elif not customer_message:

        st.warning("Please describe the customer's issue.")

    else:

        customer = get_customer_by_pnr(pnr)

        if not customer:

            st.error(
                "❌ Customer not found. Please check the PNR."
            )

        else:

            message = customer_message.lower()

            # Intent detection
            if (
                "cancel" in message
                or "cancelled" in message
                or "cancellation" in message
                or "refund" in message
            ):

                issue_type = "cancellation"

            elif (
                "delay" in message
                or "delayed" in message
            ):

                issue_type = "delay"

            else:

                issue_type = "unknown"


            if issue_type == "unknown":

                st.info(
                    "I need more information to determine "
                    "the correct resolution."
                )

            else:

                fare_difference = 0

                if (
                    "2000" in message
                    or "₹2000" in message
                    or "2,000" in message
                ):

                    fare_difference = 2000


                with st.spinner(
                    "🤖 Agent is analyzing the request..."
                ):

                    result = resolve_customer_issue(
                        pnr=pnr,
                        issue_type=issue_type,
                        customer_message=customer_message,
                        fare_difference=fare_difference
                    )


                st.divider()

                st.subheader("🤖 Agent Response")

                st.write(
                    result["customer_response"]
                )


                if result["actions"]:

                    st.subheader("✅ Actions Taken")

                    for action in result["actions"]:

                        st.success(
                            action["action"]
                        )


                if result["escalation"]:

                    st.warning(
                        "⚠️ Supervisor approval required"
                    )

                    st.write(
                        result["escalation"]["reason"]
                    )


                with st.expander(
                    "🔍 Customer Details"
                ):

                    st.write(
                        f"**Name:** {customer['name']}"
                    )

                    st.write(
                        f"**Loyalty Tier:** {customer['loyalty_tier']}"
                    )

                    st.write(
                        f"**PNR:** {customer['pnr']}"
                    )