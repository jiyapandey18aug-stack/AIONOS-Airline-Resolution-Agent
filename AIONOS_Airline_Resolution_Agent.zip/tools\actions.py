def process_refund(customer_name, pnr):
    return {
        "action": "Refund Processed",
        "customer": customer_name,
        "pnr": pnr,
        "status": "Success",
        "message": "Full refund initiated to the original payment method."
    }


def rebook_flight(customer_name, pnr, flight):
    return {
        "action": "Flight Rebooking",
        "customer": customer_name,
        "pnr": pnr,
        "new_flight": flight,
        "status": "Success",
        "message": "Customer rebooking request submitted."
    }


def issue_meal_voucher(customer_name, amount="₹500"):
    return {
        "action": "Meal Voucher",
        "customer": customer_name,
        "amount": amount,
        "status": "Success"
    }


def provide_lounge_access(customer_name):
    return {
        "action": "Lounge Access",
        "customer": customer_name,
        "status": "Success"
    }


def arrange_hotel(customer_name, duration):
    return {
        "action": "Hotel Accommodation",
        "customer": customer_name,
        "duration": duration,
        "status": "Success"
    }